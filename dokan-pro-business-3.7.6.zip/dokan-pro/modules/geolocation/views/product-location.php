<address><?php echo esc_html( $address ); ?></address>
<?php dokan_geo_get_template( 'map', array( 'layout' => 'top' ) ); ?>
