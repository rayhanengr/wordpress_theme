<div
    class="dokan-geolocation-filters-loading"
    style="position: absolute; z-index: 99999; top: 34%; left: 50%; <?php echo $show_filters !== 'on' ? 'display: none' : ''; ?>"
    >
    <img src="<?php echo DOKAN_PLUGIN_ASSEST.'/images/ajax-loader.gif'; ?>" alt="" style="display: inline-block;">
</div>