<div
    id="dokan-geolocation-locations-map"
    class="dokan-geolocation-locations-map-<?php echo esc_attr( $layout ); ?>"
></div>
