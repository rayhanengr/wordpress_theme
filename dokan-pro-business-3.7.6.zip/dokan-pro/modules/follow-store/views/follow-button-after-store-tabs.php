<li class="dokan-store-follow-store-button-container dokan-right">
    <?php echo $button; ?>
</li>
